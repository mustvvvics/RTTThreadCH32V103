#ifndef _display_h
#define _display_h

#include "headfile.h"

extern int32 count;
void display_init(void);
    
#endif
