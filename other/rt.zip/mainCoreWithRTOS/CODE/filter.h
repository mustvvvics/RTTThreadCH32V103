/*
 * filter.h
 *
 *  Created on: Jun 9, 2021
 *      Author: 29275
 */

#ifndef CODE_FILTER_H_
#define CODE_FILTER_H_

#include "headfile.h"

void AngleZ_Get(void);
void show_angle(void);

#endif /* CODE_FILTER_H_ */
