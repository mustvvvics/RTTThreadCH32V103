#ifndef _display_h
#define _display_h

#include "headfile.h"


void display_init(void);
    
#endif