

#ifndef _SEEKFREE_PRINTF_h
#define _SEEKFREE_PRINTF_h
#include "common.h"

//void    printf(const char *format, ...);
uint32  zf_sprintf(char *buf, const char *fmt, ...);





#endif
